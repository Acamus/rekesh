package com.flp.pms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForJdbc;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class createProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-DD");
		String[] discountName = request.getParameterValues("discount");

		IProductDao pdao = new ProductDaoImplForJdbc();
		Product product = new Product();
		product.setProduct_Name(request.getParameter("pName"));
		product.setDescription(request.getParameter("pDiscription"));
		product.setMaximum_Retail_Price(Double.parseDouble(request.getParameter("pMaxRetailPrice")));
		product.setRating(Float.parseFloat(request.getParameter("pRating")));
		product.setQuantity(Integer.parseInt(request.getParameter("pQuantity")));

		String strCategory = request.getParameter("category");
		List<Category> categories = pdao.getAllCategory();
		for (Category c : categories) {
			if (c.getCategory_Id() == Integer.parseInt(strCategory))
				;
			product.setCategory(c);
		}

		String strSubCategory = request.getParameter("subCategory");
		List<SubCategory> subcategories = pdao.getAllSubCategory();
		for (SubCategory sub : subcategories) {
			if (sub.getSubCategory_Id() == Integer.parseInt(strSubCategory))
				product.setSubCategory(sub);
		}

		String strSupplier = request.getParameter("supplier");
		List<Supplier> suppliers = pdao.getAllSuppliers();
		for (Supplier supl : suppliers) {
			if (supl.getSupplier_Id() == Integer.parseInt(strSupplier))
				product.setSupplier(supl);
		}

		try {
			product.setManufacturing_Date(format.parse(request.getParameter("pManufacturingDate")));
			product.setExpiry_Date(format.parse(request.getParameter("pExpityDate")));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		List<Discount> discounts = pdao.getAllDiscounts();
		List<Discount> discounts2 = new ArrayList<Discount>();
		int len = discountName.length;
		int i = 0;
		for (Discount dis : discounts) {
			if (i < len) {
				if (dis.getDiscount_Name().equalsIgnoreCase(discountName[i]))
					;
				discounts2.add(dis);
				i++;
			}
		}

		product.setDiscounts(discounts2);

		boolean bol = pdao.addProduct(product);
		if (bol)

			response.sendRedirect("pages/sucesses.html");
		else
			response.sendRedirect("pages/errorPage.html");
	}
}